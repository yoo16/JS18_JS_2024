/**
 * 二項演算
 */
var price = 500;
// TODO: price に 200 を足して再代入
console.log(price);

// TODO: price に 200 を引いて再代入
price = price - 200;
console.log(price);

// TODO: price に 2 をかけて再代入
console.log(price);

// TODO: price を 2 で割って再代入
console.log(price);

/**
 * 単項演算
 */
var quantity = 1;
// TODO: 個数を1増やす
console.log(quantity);

// TODO: 個数を1減らす
console.log(quantity);

/**
 * 複合演算
 */
var price = 500;


/**
 * テキスト連結
 */
var tableNo = 3;
var orderNo = 20341;
var orderCode = ""

// TODO: 「tableNo-orderNo」で文字列で連結

console.log(orderCode);